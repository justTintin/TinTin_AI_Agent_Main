"""
调试Java参数传递
"""
import subprocess

cmd = [
    r"C:\Java\jdk-21\bin\java.exe",
    "-cp", r"C:\Users\tintin\WorkBuddy\Claw\erp\java;C:\Users\tintin\WorkBuddy\Claw\erp\java\fastjson-1.2.83.jar",
    "com.workbuddy.erp.WdtClient",
    "suites_query",
    "--page_no", "1",
    "--page_size", "100"
]

print("执行的命令:")
print(" ".join(cmd))

result = subprocess.run(cmd, capture_output=True)
stdout = result.stdout.decode('gbk', errors='replace')
stderr = result.stderr.decode('gbk', errors='replace')

print("\nSTDOUT:")
print(stdout)
print("\nSTDERR:")
print(stderr)
