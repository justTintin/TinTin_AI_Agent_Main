"""
wdt_client.py
旺店通ERP API Python客户端
通过调用Java程序执行API请求
"""

import subprocess
import json
import re
import time
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta


class WdtClient:
    """旺店通ERP OpenAPI v2 客户端"""

    def __init__(self, base_url: str, appkey: str, appsecret: str, sid: str):
        self.base_url = base_url
        self.appkey = appkey
        self.appsecret = appsecret
        self.sid = sid
        # Java程序路径
        self.java_classpath = r"C:\Users\tintin\WorkBuddy\Claw\wdt-erp;C:\Users\tintin\WorkBuddy\Claw\wdt-erp\fastjson-1.2.83.jar"
        self.java_main_class = "com.workbuddy.erp.WdtClient"

    def call_api(self, api_method: str, params: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """
        调用API（通过Java程序）

        Args:
            api_method: API方法名
            params: 业务参数

        Returns:
            API响应字典
        """
        if params is None:
            params = {}

        # 构建命令行参数
        cmd = [
            r"C:\Java\jdk-21\bin\java.exe",
            "-cp", self.java_classpath,
            self.java_main_class,
            api_method
        ]

        # 添加参数
        for key, value in params.items():
            cmd.extend([f"--{key}", str(value)])

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                encoding='utf-8',
                timeout=60
            )

            if result.stdout:
                # 解析输出中的JSON
                json_match = re.search(r'\{.*\}', result.stdout, re.DOTALL)
                if json_match:
                    return json.loads(json_match.group())

            return {"code": -1, "message": result.stderr or "未知错误"}

        except subprocess.TimeoutExpired:
            return {"code": -1, "message": "API调用超时"}
        except Exception as e:
            return {"code": -1, "message": str(e)}

    def search_combinations(self, page_no: int = 1, page_size: int = 100,
                           start_time: Optional[str] = None,
                           end_time: Optional[str] = None) -> Dict[str, Any]:
        """
        查询组合装商品

        Args:
            page_no: 页码
            page_size: 每页条数
            start_time: 开始时间，格式 yyyy-MM-dd HH:mm:ss
            end_time: 结束时间，格式 yyyy-MM-dd HH:mm:ss

        Returns:
            包含组合装列表的响应
        """
        params = {
            'page_no': str(page_no),
            'page_size': str(page_size)
        }

        if start_time:
            params['start_time'] = start_time
        if end_time:
            params['end_time'] = end_time

        return self.call_api('suites_query', params)


def parse_goods_list(response: Dict[str, Any]) -> List[Dict[str, Any]]:
    """解析商品列表响应"""
    if response.get('code') != 0:
        print(f"[ERROR] API错误: {response.get('code')} - {response.get('message')}")
        return []

    data = response.get('data', [])
    if isinstance(data, list):
        return data
    return []


def find_max_dyc_no(goods_list: List[Dict[str, Any]], field: str = 'suite_no') -> Optional[str]:
    """查找最大的dyc-编号"""
    max_no = 0
    for item in goods_list:
        goods_no = item.get(field, '')
        if goods_no and goods_no.startswith('dyc-'):
            try:
                num = int(goods_no.split('-')[1])
                max_no = max(max_no, num)
            except (ValueError, IndexError):
                pass
    return f"dyc-{max_no:03d}" if max_no > 0 else None


def print_goods_table(goods_list: List[Dict[str, Any]], title: str = "商品列表", no_field: str = 'suite_no'):
    """打印商品表格"""
    print(f"\n{'=' * 80}")
    print(f"  {title}")
    print('=' * 80)

    if not goods_list:
        print("  (无数据)")
        return

    print(f"{'序号':<5} {'组合装编号':<15} {'组合装名称':<40}")
    print('-' * 80)

    for i, item in enumerate(goods_list[:50], 1):
        goods_no = item.get(no_field, '')[:15]
        goods_name = item.get('suite_name', '')[:40]
        print(f"{i:<5} {goods_no:<15} {goods_name:<40}")

    if len(goods_list) > 50:
        print(f"... (共 {len(goods_list)} 条)")

    print('=' * 80)


def main():
    """测试主函数"""
    from config.erp_config import ERP_BASEURL, ERP_APPKEY, ERP_APPSECRET, ERP_SID

    client = WdtClient(ERP_BASEURL, ERP_APPKEY, ERP_APPSECRET, ERP_SID)

    print("=" * 60)
    print("  旺店通ERP API 测试 (Python + Java)")
    print("=" * 60)

    # 查询组合装
    print("\n[1] 查询组合装商品...")

    # 计算时间范围（end_time必须是当前时间前几分钟）
    now = datetime.now()
    end_time = (now - timedelta(minutes=5)).strftime("%Y-%m-%d %H:%M:%S")
    start_time = (now - timedelta(days=1)).strftime("%Y-%m-%d 00:00:00")

    response = client.search_combinations(
        page_no=1,
        page_size=100,
        start_time=start_time,
        end_time=end_time
    )

    print(f"\n[响应] code={response.get('code')}, message={response.get('message')}")

    # 从响应中提取suites
    if 'suites' in response:
        goods_list = response['suites']
    else:
        goods_list = []

    print(f"[组合装数量] {len(goods_list)}")

    if goods_list:
        print_goods_table(goods_list, "ERP组合装列表")

        # 查找最大的dyc编号
        max_dyc = find_max_dyc_no(goods_list, 'suite_no')
        print(f"\n[最大dyc编号] {max_dyc if max_dyc else '无'}")

        # 统计各类型商品
        dyc_count = sum(1 for g in goods_list if g.get('suite_no', '').startswith('dyc-'))
        pt_count = sum(1 for g in goods_list if g.get('suite_no', '').startswith('pt'))
        print(f"[统计] dyc系列: {dyc_count}个, pt系列: {pt_count}个")
    else:
        print("[提示] ERP中没有找到组合装数据")


if __name__ == "__main__":
    main()
