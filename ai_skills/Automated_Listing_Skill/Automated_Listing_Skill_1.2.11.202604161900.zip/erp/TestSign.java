import java.security.MessageDigest;
import java.util.*;

public class TestSign {
    public static void main(String[] args) throws Exception {
        Map<String, String> params = new LinkedHashMap<>();
        params.put("page_no", "1");
        params.put("page_size", "100");
        params.put("start_time", "2026-04-08 00:00:00");
        params.put("end_time", "2026-04-09 16:35:00");
        params.put("timestamp", "1775724300");
        params.put("appkey", "wdt112233-jd");
        params.put("sid", "wdt112233");
        params.put("format", "json");
        params.put("v", "1.0");

        String appsecret = "7f432fcbcf8bd325ee23bc7453169d92";

        String[] keys = params.keySet().toArray(new String[0]);
        Arrays.sort(keys);

        StringBuilder query = new StringBuilder();
        for (String key : keys) {
            if (query.length() > 0) {
                query.append(';');
            }

            int len = key.length();
            query.append(String.format("%02d", len)).append('-').append(key).append(':');

            String value = params.get(key);
            len = value.length();
            query.append(String.format("%04d", len)).append('-').append(value);
        }
        query.append(appsecret);

        System.out.println("Java签名字符串: " + query.toString());

        // MD5
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] bytes = md.digest(query.toString().getBytes("UTF-8"));

        StringBuilder sign = new StringBuilder();
        for (int i = 0; i < bytes.length; i++) {
            String hex = Integer.toHexString(bytes[i] & 0xFF);
            if (hex.length() == 1) {
                sign.append("0");
            }
            sign.append(hex);
        }
        System.out.println("Java签名: " + sign.toString().toUpperCase());
    }
}
