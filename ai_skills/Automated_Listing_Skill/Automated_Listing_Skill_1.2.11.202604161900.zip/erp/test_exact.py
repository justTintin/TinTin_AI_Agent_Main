"""精确模拟Java的HTTP请求"""
import hashlib
import time
import urllib.request
import urllib.parse
from config.erp_config import ERP_BASEURL, ERP_APPKEY, ERP_APPSECRET, ERP_SID


def signRequest(params, appsecret):
    """Java风格的签名"""
    keys = sorted(params.keys())
    query = []
    for key in keys:
        if key == 'sign':
            continue
        value = params[key]
        key_len = len(key)
        val_len = len(value)
        query.append(f"{key_len:02d}-{key}:{val_len:04d}-{value}")
    sign_str = ";".join(query) + appsecret
    return hashlib.md5(sign_str.encode('utf-8')).hexdigest().upper()


def call_api():
    """精确模拟Java的HttpURLConnection请求"""
    url = ERP_BASEURL + "suites_query.php"

    params = {
        'page_no': '1',
        'page_size': '100',
        'start_time': '2026-04-08 00:00:00',
        'end_time': '2026-04-09 16:35:00',
        'timestamp': str(int(time.time())),
        'appkey': ERP_APPKEY,
        'sid': ERP_SID,
        'format': 'json',
        'v': '1.0',
    }

    # 计算签名
    sign_value = signRequest(params, ERP_APPSECRET)
    params['sign'] = sign_value

    # 精确模拟Java的postData构建方式
    post_data_list = []
    for key, value in params.items():
        encoded_key = urllib.parse.quote(key, safe='')
        encoded_value = urllib.parse.quote(value, safe='') if value else ''
        post_data_list.append(f"{encoded_key}={encoded_value}")

    post_data = '&'.join(post_data_list)
    post_data_bytes = post_data.encode('utf-8')

    print(f"[DEBUG] Post数据: {post_data}")
    print(f"[DEBUG] Post数据长度: {len(post_data_bytes)}")
    print(f"[DEBUG] 签名: {sign_value}")

    # 模拟Java的HttpURLConnection
    req = urllib.request.Request(url, data=post_data_bytes)
    req.add_header('Content-Type', 'application/x-www-form-urlencoded')
    req.add_header('Content-Length', str(len(post_data_bytes)))

    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            result = response.read().decode('utf-8')
            print(f"[DEBUG] 响应: {result[:500]}")
            return result
    except urllib.error.HTTPError as e:
        print(f"[DEBUG] HTTP错误: {e.code} - {e.reason}")
        print(f"[DEBUG] 错误响应: {e.read().decode('utf-8')}")
    except Exception as e:
        print(f"[DEBUG] 请求错误: {e}")


if __name__ == "__main__":
    call_api()
