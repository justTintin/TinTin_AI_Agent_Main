@echo off
chcp 65001 > nul
echo 正在执行打包，请稍候...
python pack_skill.py
if %ERRORLEVEL% neq 0 (
    echo 打包失败！
    pause
    exit /b %ERRORLEVEL%
)
pause
