"""
测试带时间参数的Java调用
"""
import subprocess
from datetime import datetime, timedelta

now = datetime.now()
end_time = (now - timedelta(minutes=5)).strftime("%Y-%m-%d %H:%M:%S")
start_time = (now - timedelta(days=2)).strftime("%Y-%m-%d 00:00:00")

cmd = [
    r"C:\Java\jdk-21\bin\java.exe",
    "-cp", r"C:\Users\tintin\WorkBuddy\Claw\erp\java;C:\Users\tintin\WorkBuddy\Claw\erp\java\fastjson-1.2.83.jar",
    "com.workbuddy.erp.WdtClient",
    "suites_query",
    "--page_no", "1",
    "--page_size", "100",
    "--start_time", start_time,
    "--end_time", end_time
]

print("执行的命令:")
print(" ".join(cmd))
print(f"\n参数: start_time={start_time}, end_time={end_time}")

result = subprocess.run(cmd, capture_output=True)
stdout = result.stdout.decode('gbk', errors='replace')
print("\nSTDOUT:")
print(stdout)
