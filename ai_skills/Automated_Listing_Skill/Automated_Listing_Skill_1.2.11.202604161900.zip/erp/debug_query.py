# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, 'src')
from erp_client import WdtClient
from datetime import datetime, timedelta

client = WdtClient('https://api.wangdian.cn/openapi2/', 'wdt112233-jd', '7f432fcbcf8bd325ee23bc7453169d92', 'wdt112233')

now = datetime.now()
end_time = (now - timedelta(minutes=5)).strftime('%Y-%m-%d %H:%M:%S')
start_time = (now - timedelta(days=2)).strftime('%Y-%m-%d 00:00:00')

print(f'查询: {start_time} ~ {end_time}')

# 不带suite_no参数
r = client.search_combinations(page_no=1, page_size=100, start_time=start_time, end_time=end_time)
print(f'code={r.get("code")}, total={r.get("total_count")}, items={len(r.get("suites_list", []))}')
if r.get('suites_list'):
    for s in r.get('suites_list')[:3]:
        print(f'  {s.get("suite_no")} - {s.get("suite_name")}')
