# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, 'src')
from erp_client import WdtClient
from datetime import datetime, timedelta

# ERP配置
ERP_BASEURL = "https://api.wangdian.cn/openapi2/"
ERP_APPKEY = "wdt112233-jd"
ERP_APPSECRET = "7f432fcbcf8bd325ee23bc7453169d92"
ERP_SID = "wdt112233"

client = WdtClient(ERP_BASEURL, ERP_APPKEY, ERP_APPSECRET, ERP_SID)
now = datetime.now()
end_time = (now - timedelta(minutes=3)).strftime('%Y-%m-%d %H:%M:%S')
start_time = (now - timedelta(days=29)).strftime('%Y-%m-%d 00:00:00')
print(f'开始: {start_time}, 结束: {end_time}')

# 不带 suite_no
r1 = client.search_combinations(start_time=start_time, end_time=end_time)
print(f'不带suite_no: code={r1.get("code")}, 总数={r1.get("total_count", 0)}')

# 带 suite_no
r2 = client.search_combinations(start_time=start_time, end_time=end_time, suite_no='ss10610')
print(f'带suite_no: code={r2.get("code")}, 总数={r2.get("total_count", 0)}')
