"""使用 requests 库测试旺店通API"""
import hashlib
import time
import requests
import json
from config.erp_config import ERP_BASEURL, ERP_APPKEY, ERP_APPSECRET, ERP_SID


def sign(params, appsecret):
    """计算签名"""
    sorted_keys = sorted(params.keys())
    query_parts = []
    for key in sorted_keys:
        value = params[key]
        if value is not None and str(value).strip():
            key_len = len(key)
            val_str = str(value)
            val_len = len(val_str)
            query_parts.append(f"{key_len:02d}-{key}:{val_len:04d}-{val_str}")
    sign_str = ";".join(query_parts) + appsecret
    print(f"[DEBUG] 签名字符串: {sign_str}")
    return hashlib.md5(sign_str.encode('utf-8')).hexdigest().upper()


def call_api():
    """调用API"""
    url = ERP_BASEURL + "suites_query.php"

    params = {
        'page_no': 1,
        'page_size': 100,
        'start_time': '2026-04-08 00:00:00',
        'end_time': '2026-04-09 17:00:00',
        'timestamp': str(int(time.time())),
        'appkey': ERP_APPKEY,
        'sid': ERP_SID,
        'format': 'json',
        'v': '1.0',
    }

    # 计算签名
    sign_value = sign(params, ERP_APPSECRET)
    params['sign'] = sign_value

    print(f"[DEBUG] 最终参数: {params}")

    # 使用requests发送POST请求
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'Accept': '*/*',
        'User-Agent': 'wdt-python-sdk',
    }

    response = requests.post(url, data=params, headers=headers, timeout=30)
    print(f"[DEBUG] 响应状态码: {response.status_code}")
    print(f"[DEBUG] 响应内容: {response.text}")

    return response.json()


if __name__ == "__main__":
    call_api()
