"""
测试旺店通排序参数
"""
import subprocess
import json
from datetime import datetime

JAVA_BIN = r"C:\Java\jdk-21\bin\java.exe"
JAVA_CP = r"C:\Users\tintin\WorkBuddy\Claw\wdt-erp;C:\Users\tintin\WorkBuddy\Claw\wdt-erp\fastjson-1.2.83.jar"


def run_java(params):
    cmd = [JAVA_BIN, "-cp", JAVA_CP, "com.workbuddy.erp.WdtClient"]
    for key, value in params.items():
        cmd.extend([f"--{key}", value])

    result = subprocess.run(cmd, capture_output=True, timeout=60)
    try:
        stdout = result.stdout.decode('gbk', errors='replace')
    except:
        stdout = result.stdout.decode('utf-8', errors='replace')

    parts = stdout.split('=== 响应 ===')
    if len(parts) > 1:
        json_part = parts[1]
        idx = json_part.find('{')
        if idx >= 0:
            json_str = json_part[idx:]
            bracket_count = 0
            end_idx = len(json_str)
            for i, c in enumerate(json_str):
                if c == '{':
                    bracket_count += 1
                elif c == '}':
                    bracket_count -= 1
                    if bracket_count == 0:
                        end_idx = i + 1
                        break
            return json_str[:end_idx]
    return None


def main():
    print("测试旺店通 suites_query 接口的排序参数")
    print("=" * 50)

    # 测试1: 不带排序
    print("\n[测试1] 不带排序参数:")
    params1 = {
        'page_no': '1',
        'page_size': '10',
        'start_time': '2020-01-01 00:00:00',
        'end_time': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    json_str1 = run_java(params1)
    if json_str1:
        data1 = json.loads(json_str1)
        suites1 = data1.get('suites', [])
        print(f"返回条数: {len(suites1)}")
        if suites1:
            print("前5个商家编码:")
            for s in suites1[:5]:
                print(f"  {s.get('suite_no')}")

    # 测试2: 带 order_by 参数
    print("\n[测试2] 添加 order_by=suite_no 参数:")
    params2 = {
        'page_no': '1',
        'page_size': '10',
        'start_time': '2020-01-01 00:00:00',
        'end_time': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'order_by': 'suite_no',
        'order_type': 'asc',
    }
    json_str2 = run_java(params2)
    if json_str2:
        data2 = json.loads(json_str2)
        suites2 = data2.get('suites', [])
        print(f"返回条数: {len(suites2)}")
        if suites2:
            print("前5个商家编码:")
            for s in suites2[:5]:
                print(f"  {s.get('suite_no')}")

    # 测试3: 尝试按 modify_time 排序
    print("\n[测试3] 添加 order_by=modify_time 参数:")
    params3 = {
        'page_no': '1',
        'page_size': '10',
        'start_time': '2020-01-01 00:00:00',
        'end_time': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'order_by': 'modify_time',
        'order_type': 'desc',
    }
    json_str3 = run_java(params3)
    if json_str3:
        data3 = json.loads(json_str3)
        print(f"code: {data3.get('code')}")
        if data3.get('code') != 0:
            print(f"message: {data3.get('message')}")


if __name__ == "__main__":
    main()
