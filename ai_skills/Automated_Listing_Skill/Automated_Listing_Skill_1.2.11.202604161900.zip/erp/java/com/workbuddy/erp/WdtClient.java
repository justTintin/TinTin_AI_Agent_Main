package com.workbuddy.erp;

import java.io.*;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

/**
 * 旺店通API客户端
 */
public class WdtClient {
    private String appkey;
    private String appsecret;
    private String sid;
    private String baseUrl;

    public WdtClient(String sid, String appkey, String appsecret, String baseUrl) {
        this.sid = sid;
        this.appkey = appkey;
        this.appsecret = appsecret;
        this.baseUrl = baseUrl;
        if (!this.baseUrl.endsWith("/")) {
            this.baseUrl = this.baseUrl + "/";
        }
    }

    private static byte[] encryptMD5(String data) throws IOException {
        try {
            var md = java.security.MessageDigest.getInstance("MD5");
            return md.digest(data.getBytes("UTF-8"));
        } catch (Exception e) {
            throw new IOException(e);
        }
    }

    private static String byte2hex(byte[] bytes) {
        StringBuilder sign = new StringBuilder();
        for (byte b : bytes) {
            String hex = Integer.toHexString(b & 0xFF);
            if (hex.length() == 1) {
                sign.append("0");
            }
            sign.append(hex);
        }
        return sign.toString();
    }

    public static String signRequest(Map<String, String> params, String appsecret) throws IOException {
        String[] keys = params.keySet().toArray(new String[0]);
        Arrays.sort(keys);

        StringBuilder query = new StringBuilder();
        for (String key : keys) {
            if ("sign".equals(key)) {
                continue;
            }
            if (query.length() > 0) {
                query.append(';');
            }
            int len = key.length();
            query.append(String.format("%02d", len)).append('-').append(key).append(':');
            String value = params.get(key);
            len = value.length();
            query.append(String.format("%04d", len)).append('-').append(value);
        }
        query.append(appsecret);

        byte[] bytes = encryptMD5(query.toString());
        return byte2hex(bytes);
    }

    public String execute(String relativeUrl, Map<String, String> params) throws IOException {
        params.put("appkey", this.appkey);
        params.put("sid", this.sid);
        params.put("timestamp", Long.toString(System.currentTimeMillis() / 1000));
        params.put("format", "json");
        params.put("v", "1.0");
        params.put("sign", signRequest(params, this.appsecret));

        return WebUtils.doPost(this.baseUrl + relativeUrl, params);
    }

    public static void main(String[] args) {
        String SID = "wdt112233";
        String APPKEY = "wdt112233-jd";
        String APPSECRET = "7f432fcbcf8bd325ee23bc7453169d92";
        String BASEURL = "https://api.wangdian.cn/openapi2/";

        WdtClient client = new WdtClient(SID, APPKEY, APPSECRET, BASEURL);

        Map<String, String> params = new LinkedHashMap<>();

        // 解析命令行参数：格式 --key value
        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            if (arg.startsWith("--") && i + 1 < args.length) {
                String key = arg.substring(2);
                String value = args[i + 1];
                if (!value.startsWith("--")) {
                    params.put(key, value);
                    i++;
                }
            } else if (arg.startsWith("--")) {
                // 格式 --key=value
                String keyValue = arg.substring(2);
                String[] parts = keyValue.split("=", 2);
                if (parts.length == 2) {
                    params.put(parts[0], parts[1]);
                }
            } else if (arg.equals("suites_query")) {
                // API方法名，不需要作为参数
            }
        }

        // 如果没有参数，使用默认值
        if (params.isEmpty()) {
            params.put("page_no", "1");
            params.put("page_size", "100");
        }

        try {
            System.out.println("[INFO] 查询ERP组合装数据...");
            System.out.println("[INFO] 参数: " + params);

            String result = client.execute("suites_query.php", params);

            System.out.println("\n=== 响应 ===");
            System.out.println(result);

        } catch (Exception e) {
            System.out.println("[ERROR] " + e.getMessage());
            e.printStackTrace();
        }
    }
}
