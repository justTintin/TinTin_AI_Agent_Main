$src = "d:\sophis-workspace\TinTin_AI_Agent\ai_skills\Automated_Listing_Skill"
$skillMdPath = Join-Path $src "SKILL.md"

# 从 SKILL.md 动态读取版本号
$version = "unknown"
if (Test-Path $skillMdPath) {
    $content = Get-Content $skillMdPath
    foreach ($line in $content) {
        if ($line -match "^version:\s*(.+)$") {
            $version = $matches[1].Trim()
            break
        }
    }
}

$dst = "d:\sophis-workspace\TinTin_AI_Agent\ai_skills\Automated_Listing_Skill\Automated_Listing_Skill_$version.zip"
$tmp = "$env:TEMP\Automated_Listing_Skill_$version`_content"

Write-Host "检测到版本号: $version，准备打包..."

if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
New-Item -ItemType Directory -Path $tmp | Out-Null

$excludePatterns = @('chrome_user_data', '\.zip$', '__pycache__', '\.pyc', 'chrome_user_data_debug', 'data\\results', 'data\\erp_cache')

Get-ChildItem $src -Recurse -File | ForEach-Object {
    $relPath = $_.FullName.Substring($src.Length + 1)
    $exclude = $false
    foreach ($pat in $excludePatterns) {
        if ($relPath -match $pat) { $exclude = $true; break }
    }
    if (-not $exclude) {
        $destDir = Split-Path (Join-Path $tmp $relPath) -Parent
        if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
        Copy-Item $_.FullName -Destination (Join-Path $tmp $relPath) -Force
    }
}

if (Test-Path $dst) { Remove-Item $dst -Force }
Compress-Archive -Path "$tmp\*" -DestinationPath $dst -Force
Remove-Item $tmp -Recurse -Force

Write-Host "打包完成: $dst"
Write-Host "文件大小: $((Get-Item $dst).Length / 1MB) MB"
