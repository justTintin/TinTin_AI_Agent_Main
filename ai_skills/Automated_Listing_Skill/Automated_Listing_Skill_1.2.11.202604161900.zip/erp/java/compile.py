"""
编译Java代码
"""
import subprocess
import os

java_dir = r"C:\Users\tintin\WorkBuddy\Claw\erp\java"
os.chdir(java_dir)

result = subprocess.run(
    [r"C:\Java\jdk-21\bin\javac.exe", "-encoding", "UTF-8", "com/workbuddy/erp/WdtClient.java", "com/workbuddy/erp/WebUtils.java"],
    capture_output=True
)

if result.returncode == 0:
    print("编译成功!")
else:
    print("编译失败:")
    print(result.stderr.decode('gbk', errors='replace'))
