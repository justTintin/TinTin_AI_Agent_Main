"""用相同的参数测试Python签名"""
import hashlib
from datetime import datetime

# 模拟Java的LinkedHashMap顺序
params = {}
params['page_no'] = '1'
params['page_size'] = '100'
params['start_time'] = '2026-04-08 00:00:00'
params['end_time'] = '2026-04-09 16:35:00'
params['timestamp'] = '1775724300'  # 固定timestamp
params['appkey'] = 'wdt112233-jd'
params['sid'] = 'wdt112233'
params['format'] = 'json'
params['v'] = '1.0'

appsecret = '7f432fcbcf8bd325ee23bc7453169d92'

def signRequest(params, appsecret):
    """Java风格的签名"""
    keys = sorted(params.keys())
    query = []
    for key in keys:
        if key == 'sign':
            continue
        value = params[key]
        key_len = len(key)
        val_len = len(value)
        query.append(f"{key_len:02d}-{key}:{val_len:04d}-{value}")

    sign_str = ";".join(query) + appsecret
    print(f"[DEBUG] 签名字符串: {sign_str}")
    return hashlib.md5(sign_str.encode('utf-8')).hexdigest().upper()

sign = signRequest(params, appsecret)
print(f"[DEBUG] 签名: {sign}")
