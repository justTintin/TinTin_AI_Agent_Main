@echo off
cd /d %~dp0
C:\Java\jdk-21\bin\javac.exe -encoding UTF-8 com\workbuddy\erp\*.java
echo.
echo Compile done. Press any key to exit...
pause > nul
